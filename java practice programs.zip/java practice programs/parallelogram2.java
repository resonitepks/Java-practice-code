class parallelogram2
{
	static int area() 
	{
		int b=4;
		int h=2;
		int res=b*h;
		return res;
	}
	public static void main(String[] args) 
	{
            int x= area();
		System.out.println(x);
	}
}
