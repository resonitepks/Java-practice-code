class nm 
{
	int a=100;
	void demo()
	{
	System.out.println(a);
	}
     public static void main(String[] args) 
	{
		new nm().demo();
	}
}
