class triangle19
{ double h;
	 triangle19(int b, int h) 
	{
		this.h=0.5*b*h;
		
	}
	public static void main(String[] args) 
	{
              triangle19 p =new triangle19(5,4);
			  System.out.println(p.h);
	}
}
