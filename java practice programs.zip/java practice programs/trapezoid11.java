
class trapezoid11
{
	 void area() 
	{
		int a=4;
		int b=2;
		int 
h=8;
		double res=0.5*(a+b)*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
               trapezoid11 p =new trapezoid11();
				p.area();
	}
}
