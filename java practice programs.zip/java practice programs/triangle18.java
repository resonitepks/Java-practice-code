class triangle18
{ double c;
	 triangle18() 
	{
		int h=4;
		int b=2;
		double res=0.5*h*b;
		c=res;
	}
	public static void main(String[] args) 
	{ 
		triangle18 p =new triangle18();
		System.out.println(p.c);
	}
}
