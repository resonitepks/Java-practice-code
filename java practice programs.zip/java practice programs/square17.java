
class square17
{
	square17(int a) 
	{
		int res=a*a;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
                new square17(2);
	}
}
