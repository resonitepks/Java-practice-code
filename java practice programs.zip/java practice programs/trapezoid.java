
class trapezoid
{
	static void area() 
	{
		int a=4;
		int b=2;
		int 
h=8;
		double res=0.5*(a+b)*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("main starts");
                area();
		System.out.println("main end");
	}
}
