class zero
{
	static long x= 100000;
	
	static void operation() 
	{
		System.out.println("long datatype");
	}
	public static void main(String[] args) 
	{
                operation();
		System.out.println(x);
	}
}
