class parallelogram17
{
	parallelogram17(int b, int h) 
	{
		int res=b*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
               new parallelogram17(2,3);
	}
}
