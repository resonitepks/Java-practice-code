class triangle2
{
	static double area() 
	{
		int h=4;
		int b=2;
		double res=0.5*h*b;
		return res;
	}
	public static void main(String[] args) 
	{
               double x= area();
		System.out.println(x);
	}
}
