class demo
{
	static int area() 
	{
		int a=4;
		int res=a*a;
		return res;
	}
}
class square4
{
	public static void main(String[] args) 
	{
               int x= demo.area();
		System.out.println(x);
	}
}
	

