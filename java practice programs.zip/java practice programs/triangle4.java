class perk
{
	static double area() 
	{
		int h=4;
		int b=2;
		double res=0.5*h*b;
		return res;
	}
}
class triangle4
{
	public static void main(String[] args) 
	{
               double x=perk.area();
		System.out.println(x);
	}
}


	