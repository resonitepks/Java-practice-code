class parallelogram11
{
	 void area() 
	{
		int b=4;
		int h=2;
		int res=b*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		parallelogram11 p =new parallelogram11();
                p.area();
	}
}
