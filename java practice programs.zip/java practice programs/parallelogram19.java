class parallelogram19
{  int h;
	parallelogram19(int b, int h) 
	{
		this.h=b*h;
		
	}
	public static void main(String[] args) 
	{
              parallelogram19 p= new parallelogram19(2,3);
			  System.out.println(p.h);
	}
}
