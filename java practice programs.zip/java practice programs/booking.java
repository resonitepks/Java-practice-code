class irctc 
{
 void booking()
{
 System.out.println("They have booked successfully");
}
}
class p
{
	static void train(irctc a)
{
		 a.booking();
}
} 	 
class q
{
	static void train(irctc b) 
{
		 b.booking();
}
}
class booking
{
 public static void main(String[] args) 
{
	irctc x = new irctc ();
		p.train(x);
		q.train(x);
}
}
