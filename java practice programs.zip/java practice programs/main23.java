class father
{
	void relation()
	{
		System.out.println("i am ur father);
}
}
class son extends father
{
	void beta()
	{
		System.out.println("i am ur son");
}
}

class main23
{
	public static void main(String[] args) 
	{
		father d=new son();
		d.relation();
		son s=(son).d();
		s.relation();
		s.beta();
	}
}

