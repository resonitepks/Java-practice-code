class meta
{
	void app()
	{
		System.out.println("i am fb");
}
}
class whatsapp extends meta
{
	void software()
	{
		System.out.println("i am whatsapp");
}
}

class main21
{
	public static void main(String[] args) 
	{
		meta d=new whatsapp();
		d.app();
		whatsapp r=(whatsapp).d();
		r.software();
		r.app();
	}
}

