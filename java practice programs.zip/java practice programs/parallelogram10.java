class demo
{
	 int area() 
	{
		int b=4;
		int h=2;
		int res=b*h;
		return res;
	}
}
class parallelogram10
{
	public static void main(String[] args) 
	{
            int x= new demo().area();
		System.out.println(x);
	}
}
	

