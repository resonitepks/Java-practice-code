class square7
{
   int area() 
	{
		int a=4;
		int res=a*a;
		return res;
	}
	public static void main(String[] args) 
	{
               int x= new square7().area();
		System.out.println(x);
	}
}
