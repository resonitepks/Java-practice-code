class student2
{  
    student2( String sname, int sem, double cgpa) 
	{
	 System.out.println("student's name is"+ sname);
	 System.out.println("student's sem is"+ sem);
	 System.out.println("student's cgpa is"+ cgpa);
	}
	public static void main(String[] args) 
	{ 
		new student2("vansh", 8, 8.04 );
	}
}
