class parallelogram
{
	static void area() 
	{
		int b=4;
		int h=2;
		int res=b*h;
		System.out.println(res);
	}
}
class $parallelogram
{
	public static void main(String[] args) 
	{
           parallelogram.area();
		
	}
}

