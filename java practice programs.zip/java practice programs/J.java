class J 
{
	static void perfect(int x) 
	{
		int sum=0;
		for (int i=1; i<x; i++)
		{
			if (x%i==0)
			{
				sum= sum+i;
			}
		}
		if (x== sum)
		{
			System.out.println("it's perfect number");
	    }
		else 
		{
           System.out.println("it's not perfect number");
		}
	}
	public static void main(String[] args) 
	{
		perfect(30);
	}
}
