class parallelogram
{
	static void area() 
	{
		int b=4;
		int h=2;
		int res=b*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("main starts");
                area();
		System.out.println("main end");
	}
}
