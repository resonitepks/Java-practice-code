class rectangle
{
	 void area(int w, int h) 
	{
		int res=w*h;
		System.out.println(res);
	}
}
class rectangle14
{
	public static void main(String[] args) 
	{
		rectangle12 p =new rectangle12();
                p.area(2,3);
		
	}
}


