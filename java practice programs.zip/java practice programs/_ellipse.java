class ellipse
{
	static void area() 
	{
		int a=4;
		int b=2;
		final double pi=3.142;
		double res= pi*a*b;
		System.out.println(res);
	}
}
class _ellipse
{
	public static void main(String[] args) 
	{
              ellipse.area();
		
	}
}
	

