class add1
{
	static void area(int a, int b, int c ) 
	{
		int res= a+b+c;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("start");
                area(2,3,5);
		System.out.println("end");
	}
}
