class demo
{
	static double area() 
	{
		int a=4;
		int b=2;
		final double pi=3.142;
		double res= pi*a*b;
		return res;
	}
}
class ellipse4
{
	public static void main(String[] args) 
	{
              double x= demo.area();
		System.out.println(x);
	}
}
	

