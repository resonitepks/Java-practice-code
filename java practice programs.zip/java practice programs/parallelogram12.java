class parallelogram12
{
	 void area(int b, int h) 
	{
		int res=b*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
parallelogram12 p = new parallelogram12();
                p.area(2,3);
	}
}
