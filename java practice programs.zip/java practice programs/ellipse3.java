class demo
{
	static void area(int a, int b, double pi) 
	{
		double res= pi*a*b;
		System.out.println(res);
	}
}
class ellipse3
{
	public static void main(String[] args) 
	{
		System.out.println("start");
              demo.area(4,2,3.142);
		System.out.println("end");
	}
}
	

