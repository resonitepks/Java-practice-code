class tata
{
	int x= 3;
}
class nano extends tata
{
	void car()
	{
		System.out.println("tata nano");
	}
}
class harrier extends tata 
{
	void vehicle() 
	{
		System.out.println("tata harrier");
	}
}
class main51
{
	public static void main() 
	{
		nano p = new nano();
	     p.car();
		System.out.println(p.x);
		harrier r = new harrier();
	    r.vehicle();
		System.out.println(r.x);
	}
}
