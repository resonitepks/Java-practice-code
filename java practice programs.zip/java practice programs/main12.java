class father 
{
	int a= 1000;
}
class son extends father
{
	// int a=1000;
	void beta() 
	{
		System.out.println("hey");
	}
}
class daughter extends father
{ // int a=1000;
	void beti() 
	{
		System.out.println("Hello");
	}
}
class main12
{
	public static void main(String[] args) 
	{
		son s= new son();
		s.beta();
		System.out.println(s.a);
		daughter d = new daughter();
		d.beti();
		System.out.println(d.a);
	}
}

