class triangle5
{
	 void area() 
	{
		int h=4;
		int b=2;
		double res=0.5*h*b;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("main starts");
                new triangle5().area();
		System.out.println("main end");
	}
}
