class tata
{
	void motor()
	{
		System.out.println("i am tata);
}
}
class nano extends tata
{
	void car()
	{
		System.out.println("i am nano");
}
}

class main24
{
	public static void main(String[] args) 
	{
		tata d=new nano();
		d.motor();
		nano s=(nano).d();
		s.motor();
		s.car();
	}
}

