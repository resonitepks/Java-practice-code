
class square19
{ int a;
	square19(int a) 
	{
		this.a=a*a;
		
	}
	public static void main(String[] args) 
	{
               square19 p= new square19(2);
			   System.out.println(p.a);
	}
}
