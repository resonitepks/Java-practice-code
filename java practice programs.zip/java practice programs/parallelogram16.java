class parallelogram16
{
	 parallelogram16() 
	{
		int b=4;
		int h=2;
		int res=b*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
            new parallelogram16();
	}
}
