class demo
{
	static int area() 
	{
		int b=4;
		int h=2;
		int res=b*h;
		return res;
	}
}
class parallelogram4
{
	public static void main(String[] args) 
	{
            int x= demo.area();
		System.out.println(x);
	}
}
	

