class instav1
{
	void feature()
	{
		System.out.println("signup, login, story");
}
}
class instav2 extends instav1
{
	void feature()
	{
		System.out.println("signup, login, story, reels");
}
}

class main15
{
	public static void main(String[] args) 
	{
		instav1 i=new instav2();
		i.feature();
	}
}

