class triangle
{
	 void area(int b, int h) 
	{
		double res=0.5*b*h;
		System.out.println(res);
	}
}
class triangle14
{
	public static void main(String[] args) 
	{
		 triangle12 p= new triangle12();
                p.area(5,4);
		
	}
}

