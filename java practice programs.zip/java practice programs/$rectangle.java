class rectangle
{
	static void area() 
	{
		int w=4;
		int h=2;
		int res=w*h;
		System.out.println(res);
	}
	}
	class $rectangle
	{
		public static void main(String[] args) 
	{
               rectangle.area();
	}
	
		
}
