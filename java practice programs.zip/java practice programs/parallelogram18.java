class parallelogram18
{ int d;
	 parallelogram18() 
	{
		int b=4;
		int h=2;
		int res=b*h;
		d= res;
		
	}
	public static void main(String[] args) 
	{
        parallelogram18 p = new parallelogram18();
			System.out.println(p.d);
	}
}
