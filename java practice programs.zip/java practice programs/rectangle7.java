class rectangle7
{
	int area() 
	{
		int w=4;
		int h=2;
		int res=w*h;
		return res;
	}
	public static void main(String[] args) 
	{
               int x= new rectangle7(). area();
		System.out.println(x);
	}
}
