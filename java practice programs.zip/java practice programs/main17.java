class telegramv1
{
	void feature()
	{
		System.out.println("chat, group, channel");
}
}
class telegramv2 extends telegramv1
{
	void feature()
	{
		System.out.println("chat, group, channel,story");
}
}

class main17
{
	public static void main(String[] args) 
	{
		telegramv1 i=new telegramv2();
		i.feature();
	}
}

