class job
{
	void life()
	{
		System.out.println("life is happy");
}
}
class money extends job
{
	void condition()
	{
		System.out.println("i am rich");
}
}

class main20
{
	public static void main(String[] args) 
	{
		job d=new money();
		d.life();
		money p=(money).d();
		p.conition();
		p.life
	}
}

