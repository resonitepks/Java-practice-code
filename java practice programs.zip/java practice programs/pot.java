class pot
{
	static void strong(int b) 
	{   int copy=b;
		int sum=0;
		while (b!=0)
		{ 
			int rem= b%10;
			int fact=1;
			for (int i=1; i<=rem; i++)
			{
				fact= fact*i;
			}
			sum= sum+fact;
			  b=b/10;
			}
		if (sum==copy)
		{
			System.out.println("it's strong number");
	    }
		else 
		{
           System.out.println("it's not strong number");
		}
	}
	public static void main(String[] args) 
	{
		strong(371);
	}
}
