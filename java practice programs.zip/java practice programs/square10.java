class demo
{
	 int area() 
	{
		int a=4;
		int res=a*a;
		return res;
	}
}
class square10
{
	public static void main(String[] args) 
	{
               int x= new demo().area();
		System.out.println(x);
	}
}
	

