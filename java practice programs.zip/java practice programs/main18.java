class amazonv1
{
	void payment()
	{
		System.out.println("credit card, debit card,upi");
}
}
class amazonv2 extends amazonv1
{
	void payment()
	{
		System.out.println("credit card, debit card,upi,pay later");
}
}

class main18
{
	public static void main(String[] args) 
	{
	amazonv1 i= new amazonv2();
		i.payment();
	}
}

