class sam
{
	int x=8;
	static void op(sam b) 
	{
	 System.out.println(b.x);
	}
	public static void main(String[] args) 
	{ 
		sam p =new sam();
		op(p);
	}
}

