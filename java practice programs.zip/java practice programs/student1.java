class student1
{  
 String a;
 int b;
double c;
	 student1( String sname, int sem,double cgpa) 
	{
	 a=sname;
	 b=sem;
	 c=cgpa;
	}
	public static void main(String[] args) 
	{ 
		student1 p =new student1("vansh", 8, 8.04);
		System.out.println(p.a);
		System.out.println(p.b);
		System.out.println(p.c);
	}
}
