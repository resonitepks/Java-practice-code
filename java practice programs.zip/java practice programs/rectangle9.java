class hero
{
	void area(int w, int h) 
	{
		int res=w*h;
		System.out.println(res);
	}
}
class rectangle9
{
	public static void main(String[] args) 
	{
                new hero().area(2,3);
	}
}


