class rectangle1
{
	static void area(int w, int h) 
	{
		int res=w*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("start");
                area(2,3);
		System.out.println("end");
	}
}
