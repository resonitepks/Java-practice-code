class demo1
{
	static void prime(int x) 
	{
		int count=0;
		for (int i=1; i<=x; i++)
		{
			if (x%i==0)
			{
				count++;
			}
		}
		if (count==2)
		{
			System.out.println("it's prime number");
	    }
		else 
		{
           System.out.println("it's not prime number");
		}
	}
	public static void main(String[] args) 
	{
		prime(17);
	}
}
