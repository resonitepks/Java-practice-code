class multi
{
	static void multiply(int a, int b, int c ) 
	{
		int res= a*b*c;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("start");
                area(20,5,10);
		System.out.println("end");
	}
}
