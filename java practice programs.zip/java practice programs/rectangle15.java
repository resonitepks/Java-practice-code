class rectangle
{
	 int area() 
	{
		int w=4;
		int h=2;
		int res=w*h;
		return res;
	}
}
class rectangle15
{
	public static void main(String[] args) 
	{
		rectangle13 t=new rectangle13();
               int x= t.area();
		System.out.println(x);
	}
}

