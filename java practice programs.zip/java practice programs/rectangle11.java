class rectangle11
{
	 void area() 
	{
		int w=4;
		int h=2;
		int res=w*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		rectangle11 p =new rectangle11();
                p.area();
	}
}
