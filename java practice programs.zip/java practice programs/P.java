class P 
{
	static void perfect(int y) 
	{
		int sum=0;
		for (int i=1; i<y; i++)
		{
			if (y%i==0)
			{
				sum= sum+i;
			}
		}
		if (y== sum)
		{
			System.out.println("it's perfect number");
	    }
		else 
		{
           System.out.println("it's not perfect number");
		}
	}
	public static void main(String[] args) 
	{
		perfect(28);
	}
}
