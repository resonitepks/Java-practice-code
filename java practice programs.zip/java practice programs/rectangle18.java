class rectangle18
{ int b;
rectangle18() 
	{
		int w=4;
		int h=2;
		int res=w*h;
		b=res;
		
	}
	public static void main(String[] args) 
	{
               rectangle18 p= new rectangle18();
			   System.out.println(p.b);
	}
}
