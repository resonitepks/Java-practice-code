class R 
{
	static void perfect(int z) 
	{
		int sum=0;
		for (int i=1; i<z; i++)
		{
			if (z%i==0)
			{
				sum= sum+i;
			}
		}
		if (z== sum)
		{
			System.out.println("it's perfect number");
	    }
		else 
		{
           System.out.println("it's not perfect number");
		}
	}
	public static void main(String[] args) 
	{
		perfect(29);
	}
}
