class parallelogram7
{
	 int area() 
	{
		int b=4;
		int h=2;
		int res=b*h;
		return res;
	}
	public static void main(String[] args) 
	{
            int x= new parallelogram7().area();
		System.out.println(x);
	}
}
