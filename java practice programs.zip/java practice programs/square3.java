
class sem
{
	static void area(int a)
		
	{
		int res=a*a;
		System.out.println(res);
	}
}
class square3
{
	public static void main(String[] args) 
	{
                sem.area(2);
	}
}
