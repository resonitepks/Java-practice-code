
class square
{
	 void area(int a) 
	{
		int res=a*a;
		System.out.println(res);
	}
}
class square14
{
	public static void main(String[] args) 
	{
		square12 p = new square12();
                p.area(2);
		
	}

}
