class square18
{ int b;
square18() 
	{
		int a=4;
		int res=a*a;
		b =res;
		
	}
	public static void main(String[] args) 
	{
		square18 p =new square18();
		System.out.println(p.b);
	}
}
