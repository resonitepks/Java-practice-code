class circle11
{
	 void area() 
	{
		double pi=3.142;
		int r=2;
		double res=pi*r*r;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		circle11 p = new circle11();
                p.area();
		
	}
}
