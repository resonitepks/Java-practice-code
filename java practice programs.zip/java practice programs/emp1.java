class emp1
{  
 String a;
 int b;
double c;
	 emp1( String ename, int age,double sal) 
	{
	 a=ename;
	 b=age;
	 c=sal;
	}
	public static void main(String[] args) 
	{ 
		emp1 p =new emp1("ram", 22, 500.50);
		System.out.println(p.a);
		System.out.println(p.b);
		System.out.println(p.c);
	}
}
