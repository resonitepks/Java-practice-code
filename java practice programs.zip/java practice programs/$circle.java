class circle
{
	static void area() 
	{
		final double pi=3.142;
		int r=5;
		double res=pi*r*r;
		System.out.println(res);
	}
}
class $circle
{
	public static void main(String[] args) 
	{
	   circle.area();
		
	}
}
	

