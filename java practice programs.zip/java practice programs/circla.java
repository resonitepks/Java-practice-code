class circla
{
	static void area(double pi=3.142, int r=2;) 
	{
		double res=pi*r*r;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("main starts");
                area(3.142,2);
		System.out.println("main end");
	}
}
