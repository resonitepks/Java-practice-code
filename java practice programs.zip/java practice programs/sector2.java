class sector2
{
	static double area() 
	{
		int r=2;
		int theta= 60;
		double res= 0.5*r*r*theta;
		return res;
	}
	public static void main(String[] args) 
	{
              double x= area();
		System.out.println(x);
	}
}
