class square11
{
	void area() 
	{
		int a=4;
		int res=a*a;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		
              square11 p = new square11(); 
				  p.area();
	}
}
