class rectangle17
{
	 rectangle17(int w, int h) 
	{
		int res=w*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
               new rectangle17(2,3);
	}
}
