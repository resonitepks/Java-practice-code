class triangle11
{
	 void area() 
	{
		int h=4;
		int b=2;
		double res=0.5*h*b;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		
            triangle11 p =new triangle11();
			p.area();
		
	}
}
