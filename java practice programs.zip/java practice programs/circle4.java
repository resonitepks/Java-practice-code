class demo
{
	static double area() 
	{
		final double pi=3.142;
		int r=5;
		double res=pi*r*r;
		return res;
	}
}
class circle4
{
	public static void main(String[] args) 
	{
	   double x= demo.area();
		System.out.println(x);
	}
}
	

