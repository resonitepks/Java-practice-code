class square2
{
	static int area() 
	{
		int a=4;
		int res=a*a;
		return res;
	}
	public static void main(String[] args) 
	{
               int x= area();
		System.out.println(x);
	}
}
