class rectangle5
{
	void area() 
	{
		int w=4;
		int h=2;
		int res=w*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("main starts");
                new rectangle5().area();
		System.out.println("main end");
	}
}
