class triangle6
{
	 void area(int b, int h) 
	{
		double res=0.5*b*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("start");
              new triangle6().area(5,4);
		System.out.println("end");
	}
}
