class ramesh
{
	int x=10;
	static void option(ramesh b) 
	{
	 System.out.println(b.x);
	}
	public static void main(String[] args) 
	{ 
		ramesh p =new ramesh();
		option(p);
	}
}

