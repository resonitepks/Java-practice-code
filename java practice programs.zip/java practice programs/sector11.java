class sector11
{
	void area() 
	{
		int r=2;
		int theta= 60;
		double res= 0.5*r*r*theta;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
      sector11 p =new sector11();
              p.area();
	}
}
