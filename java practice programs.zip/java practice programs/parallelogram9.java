class demo
{
     void area(int b, int h) 
	{
		int res=b*h;
		System.out.println(res);
	}
}
class parallelogram9
{
	public static void main(String[] args) 
	{
                new demo().area(2,3);
	}
}

	
