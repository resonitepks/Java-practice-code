class perk
{
	double area() 
	{
		int h=4;
		int b=2;
		double res=0.5*h*b;
		return res;
	}
}
class triangle10
{
	public static void main(String[] args) 
	{
               double x=new perk().area();
		System.out.println(x);
	}
}


	