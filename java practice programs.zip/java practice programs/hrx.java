class hrx
{
	static char x='y';
	
	static void operation() 
	{
		System.out.println("i love java");
	}
	public static void main(String[] args) 
	{
                operation();
		System.out.println(x);
	}
}
