class emp2
{  
    emp2( String ename, int age,double sal) 
	{
	 System.out.println("employee name is"+ ename);
	 System.out.println("employee age is"+ age);
	 System.out.println("employee salary is"+ sal);
	}
	public static void main(String[] args) 
	{ 
		new emp2("ram", 22, 500.50);
	}
}
