class rat
{
	static void strong(int c) 
	{   int copy=c;
		int sum=0;
		while (c!=0)
		{ 
			int rem= c%10;
			int fact=1;
			for (int i=1; i<=rem; i++)
			{
				fact= fact*i;
			}
			sum= sum+fact;
			  c=c/10;
			}
		if (sum==copy)
		{
			System.out.println("it's strong number");
	    }
		else 
		{
           System.out.println("it's not strong number");
		}
	}
	public static void main(String[] args) 
	{
		strong(373);
	}
}
