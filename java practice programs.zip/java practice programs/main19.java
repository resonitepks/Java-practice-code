class irctcv1
{
	void payment()
	{
		System.out.println("credit card, debit card,upi");
}
}
class irctcv2 extends irctcv1
{
	void payment()
	{
		System.out.println("credit card, debit card,upi,irctc wwallet");
}
}

class main19
{
	public static void main(String[] args) 
	{
	irctcv1 i= new irctcv2();
		i.payment();
	}
}

