class triangle
{
	static void area() 
	{
		int h=4;
		int b=2;
		double res=0.5*h*b;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("main starts");
                area();
		System.out.println("main end");
	}
}
