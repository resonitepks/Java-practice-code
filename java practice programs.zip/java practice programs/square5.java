class square5
{
	void area() 
	{
		int a=4;
		int res=a*a;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("main starts");
                new square5().area();
		System.out.println("main end");
	}
}
