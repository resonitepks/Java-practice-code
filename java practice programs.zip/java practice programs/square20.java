
class square20
{
	static void area(int a) 
	{
		int res=a*a;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
                area(2);
	}
}
