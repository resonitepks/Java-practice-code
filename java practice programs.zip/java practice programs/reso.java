class reso
{
	static double x=99.99;
	
	static void operation() 
	{
		System.out.println("java is easy");
	}
	public static void main(String[] args) 
	{
                operation();
		System.out.println(x);
	}
}
