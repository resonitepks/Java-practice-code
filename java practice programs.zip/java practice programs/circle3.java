class demo
{
	static void area(double pi, int r) 
	{
		double res=pi*r*r;
		System.out.println(res);
	}
}
class circle3
{
	public static void main(String[] args) 
	{
		System.out.println("main starts");
                demo.area(3.142,5);
		System.out.println("main end");
	}
}
	
