class emp
{
	static double area() 
	{
		int r=2;
		int theta= 60;
		double res= 0.5*r*r*theta;
		return res;
	}
}
class sector4
{
	public static void main(String[] args) 
	{
              double x= emp.area();
		System.out.println(x);
	}
}
	

