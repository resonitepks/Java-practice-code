class demo
{
	static void area(int a, int b, int h) 
	{
		double res= 0.5*(a+b)*h;
		System.out.println(res);
	}
}
 class trapezoid3
 { 
	 public static void main(String[] args) 
	{
		System.out.println("start");
               demo.area(4,2,8);
		System.out.println("end");
	}

 }
	
	

