class uber 
{
 void order()
{
 System.out.println("They have ordered successfully");
}
}
class x
{
	 static void car(uber  a)
{
		 a.order();
}
}
class y
{
	static void car(uber  b) 
{
		 b.order();
}
}
class status
{
 public static void main(String[] args) 
{
	uber p = new uber ();
		x.car(p);
		y.car(p);
}
}
