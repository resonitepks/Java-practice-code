class rakesh
{
	int x=2;
	static void ghanti(rakesh b) 
	{
	 System.out.println(b.x);
	}
	public static void main(String[] args) 
	{ 
		rakesh p =new rakesh();
		ghanti(p);
	}
}

