class whatsappv1
{
	void feature()
	{
		System.out.println("signup, login, story");
}
}
class whatsappv2 extends whatsappv1
{
	void feature()
	{
		System.out.println("signup, login, story, emoji");
}
}

class main16
{
	public static void main(String[] args) 
	{
		whatsappv1 i=new whatsappv2();
		i.feature();
	}
}

