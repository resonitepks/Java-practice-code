class rectangle19
{ int h;
	 rectangle19(int w, int h) 
	{
		this.h=w*h;
		
	}
	public static void main(String[] args) 
	{
            rectangle19 p =new rectangle19(2,3);
			System.out.println(p.h);
	}
}
