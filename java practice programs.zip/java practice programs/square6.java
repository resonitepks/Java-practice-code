
class square6
{
	 void area(int a) 
	{
		int res=a*a;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("start");
                new square6().area(2);
		System.out.println("end");
	}
}
