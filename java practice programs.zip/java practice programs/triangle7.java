class triangle7
{
	double area() 
	{
		int h=4;
		int b=2;
		double res=0.5*h*b;
		return res;
	}
	public static void main(String[] args) 
	{
               double x= new triangle7().area();
		System.out.println(x);
	}
}
