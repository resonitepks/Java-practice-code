class parallelogram1
{
	static void area(int b, int h) 
	{
		int res=b*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("start");
                area(2,3);
		System.out.println("end");
	}
}
