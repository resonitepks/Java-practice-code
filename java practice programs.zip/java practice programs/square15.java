class square
{
	 int area() 
	{
		int a=4;
		int res=a*a;
		return res;
	}
}
class square15
{ 
	public static void main(String[] args) 
	{
             square13 t= new square13(); 
			   int x= t.area();
		System.out.println(x);
	}
}

