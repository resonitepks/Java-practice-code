class demo
{
	static void area(int b, int h) 
	{
		int res=b*h;
		System.out.println(res);
	}
}
class parallelogram3
{
	public static void main(String[] args) 
	{
		System.out.println("start");
                demo.area(2,3);
		System.out.println("end");
	}
}

	
