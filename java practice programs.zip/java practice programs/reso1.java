class reso1
{
	static void prime(int y) 
	{
		int count=0;
		for (int i=1; i<=y; i++)
		{
			if (y%i==0)
			{
				count++;
			}
		}
		if (count==2)
		{
			System.out.println("it's prime number");
	    }
		else 
		{
           System.out.println("it's not prime number");
		}
	}
	public static void main(String[] args) 
	{
		prime(71);
	}
}
