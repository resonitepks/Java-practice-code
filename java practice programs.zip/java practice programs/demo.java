class demo 
{
	demo(int r,double pi)
    { 
	  double c=pi*r*r;
	  System.out.println(c);
	}
	public static void main(String[] args) 
	{
		new demo(3,3.142);
	}
}
