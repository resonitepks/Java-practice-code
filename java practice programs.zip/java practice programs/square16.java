class square16
{
square16() 
	{
		int a=4;
		int res=a*a;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		new square16();
	}
}
