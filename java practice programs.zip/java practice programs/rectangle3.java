class hero
{
	static void area(int w, int h) 
	{
		int res=w*h;
		System.out.println(res);
	}
}
class rectangle3
{
	public static void main(String[] args) 
	{
		System.out.println("start");
                hero.area(2,3);
		System.out.println("end");
	}
}


