class triangle13
{
	 double area() 
	{
		int h=4;
		int b=2;
		double res=0.5*h*b;
		return res;
	}
	public static void main(String[] args) 
	{
		triangle13 t = new triangle13();
               double x= t.area();
		System.out.println(x);
	}
}
