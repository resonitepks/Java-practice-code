class ram
{
	int x=6;
	static void opt(ram b) 
	{
	 System.out.println(b.x);
	}
	public static void main(String[] args) 
	{ 
		ram p =new ram();
		opt(p);
	}
}

