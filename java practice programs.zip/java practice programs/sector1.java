class sector1
{
	static void area(int r, int theta ) 
	{
		double res= 0.5*r*r*theta;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("start");
                area(2,60);
		System.out.println("end");
	}
}
