class mother
{
	void relation()
	{
		System.out.println("i am ur mom");
}
}
class daughter extends mother
{
	void beti()
	{
		System.out.println("i am ur daughter");
}
}

class main22
{
	public static void main(String[] args) 
	{
		mother d=new daughter();
		d.relation();
		daughter s=(daughter).d();
		s.relation();
		s.beti();
	}
}

