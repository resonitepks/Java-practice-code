class ellipse2
{
	static double area() 
	{
		int a=4;
		int b=2;
		final double pi=3.142;
		double res= pi*a*b;
		return res;
	}
	public static void main(String[] args) 
	{
              double x= area();
		System.out.println(x);
	}
}
