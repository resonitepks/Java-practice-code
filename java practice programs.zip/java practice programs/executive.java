class flipkart 
{
 void shopping()
{
 System.out.println("They have purchased successfully");
}
}
class ram
{
	 static void buy(flipkart a)
{
		 a.shopping();
}
}
class shyam
{
	static void buy(flipkart b) 
{
		 b.shopping();
}
}
class executive
{
 public static void main(String[] args) 
{
		flipkart p = new flipkart();
		ram.buy(p);
		shyam.buy(p);
}
}
