class square
{
	static void area() 
	{
		int a=4;
		int res=a*a;
		System.out.println(res);
	}
	
}
class _square
{
	public static void main(String[] args) 
	{
               square.area();
		
	}
}

