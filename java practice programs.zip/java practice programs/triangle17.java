class triangle17
{
	 triangle17(int b, int h) 
	{
		double res=0.5*b*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
              new triangle17(5,4);
	}
}
