
class sem
{
	void area(int a)
		
	{
		int res=a*a;
		System.out.println(res);
	}
}
class square9
{
	public static void main(String[] args) 
	{
                new sem().area(2);
	}
}
