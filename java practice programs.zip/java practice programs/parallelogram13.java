class parallelogram13
{
	 int area() 
	{
		int b=4;
		int h=2;
		int res=b*h;
		return res;
	}
	public static void main(String[] args) 
	{
     parallelogram13 t= new parallelogram13();
            int x= t.area();
		System.out.println(x);
	}
}
