class circle1
{
	static void area(double pi, int r) 
	{
		double res=pi*r*r;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("main starts");
                area(3.142,5);
		System.out.println("main end");
	}
}
