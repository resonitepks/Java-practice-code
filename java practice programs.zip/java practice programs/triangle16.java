class triangle16
{
	 triangle16() 
	{
		int h=4;
		int b=2;
		double res=0.5*h*b;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{ 
		new triangle16();
	}
}
