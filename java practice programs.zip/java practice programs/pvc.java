class pvc
{
	static int x= 420;
	
	static void operation() 
	{
		System.out.println("integer datatype");
	}
	public static void main(String[] args) 
	{
                operation();
		System.out.println(x);
	}
}
