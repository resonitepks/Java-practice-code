class student
{  
 String sname;
 int sem;
double cgpa;
	 student( String sname, int sem,double cgpa) 
	{
	 this.sname=sname;
	 this.sem=sem;
	 this.cgpa=cgpa;
	}
	public static void main(String[] args) 
	{ 
		student p =new student("vansh", 8, 8.04);
		System.out.println(p.sname);
		System.out.println(p.sem);
		System.out.println(p.cgpa);
	}
}
