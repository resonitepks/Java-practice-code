class meta
{
	int p= 2;
}
class whatsapp extends meta
{
	void app()
	{
		System.out.println("Hello Whatsappp");
	}
}
class instagram extends meta 
{
	void software() 
	{
		System.out.println("Hello ig");
	}
}
class main4
{
	public static void main(String[] args) 
	{
		whatsapp a = new whatsapp();
		a.app();
		System.out.println(a.p);
		instagram b = new instagram();
		b.software();
		System.out.println(b.p);
	}
}
