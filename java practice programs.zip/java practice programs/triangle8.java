class triangle
{
	void area() 
	{
		int h=4;
		int b=2;
		double res=0.5*h*b;
		System.out.println(res);
	}
}

class triangle8
	{
      public static void main(String[]args) 
	{
               new triangle().area();
		
	}
	}
	
