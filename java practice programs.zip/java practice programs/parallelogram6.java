class parallelogram6
{
	void area(int b, int h) 
	{
		int res=b*h;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("start");
               new parallelogram6(). area(2,3);
		System.out.println("end");
	}
}
