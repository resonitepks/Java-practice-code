class emp
{  
 String ename;
 int age;
double sal;
	 emp( String ename, int age,double sal) 
	{
	 this.ename=ename;
	 this.age=age;
	 this.sal=sal;
	}
	public static void main(String[] args) 
	{ 
		emp p =new emp("ram", 22, 500.50);
		System.out.println(p.ename);
		System.out.println(p.age);
		System.out.println(p.sal);
	}
}
