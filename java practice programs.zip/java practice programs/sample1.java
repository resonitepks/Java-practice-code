class sample1
{
  static void operate()
{  
  int i=5;  
  while(i>=1)
{
	  if(i%2==1)
{ 
   System.out.println(i);
}  
      i--;
}
}
  public static void main(String[] args) 
	{
		operate();
	}
}


