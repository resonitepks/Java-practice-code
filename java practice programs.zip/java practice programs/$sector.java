class sector
{
	static void area() 
	{
		int r=2;
		int theta= 60;
		double res= 0.5*r*r*theta;
		System.out.println(res);
	}
}
class $sector
{
	public static void main(String[] args) 
	{
              sector.area();
		
	}
}
	

