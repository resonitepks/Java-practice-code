class hero
{
	int area() 
	{
		int w=4;
		int h=2;
		int res=w*h;
		return res;
	}
}
class rectangle10
{ 
public static void main(String[] args) 
	{
               int x=new hero().area();
		System.out.println(x);
	}
}
	

