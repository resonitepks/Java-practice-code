class pr 
{
	 static void perfect(int x) 
	{
		 int sum=0;
		for (int x=1; i<x; i++ )
		{
			if (x%i==0)
			{ 
				sum=sum +i;
			}
		}
		if (x==sum)
		{
        System.out.println(x+"is a perect ");
		}
		else
		{
			System.out.println(x+"is  not a perect ");
	}
	}
	public static void main(String[] args) 
	{
		perfect(6);
	}
}
