class ellipse11
{
	 void area() 
	{
		int a=4;
		int b=2;
		final double pi=3.142;
		double res= pi*a*b;
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
       ellipse11 p =new ellipse11();
              p.area();
	}
}
