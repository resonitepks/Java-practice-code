
class demo
{
	static double area() 
	{
		int a=4;
		int b=2;
		int h=8;
		double res=0.5*(a+b)*h;
		return res;
	}
}
class trapezoid4
{ 
	public static void main(String[] args) 
	{
                double x= demo.area();
		System.out.println(x);
	}
}
	
