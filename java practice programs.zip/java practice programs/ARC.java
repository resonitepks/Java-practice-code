class ARC
{
	static boolean x= true;
	
	static void operation() 
	{
		System.out.println("boolean datatype");
	}
	public static void main(String[] args) 
	{
                operation();
		System.out.println(x);
	}
}
