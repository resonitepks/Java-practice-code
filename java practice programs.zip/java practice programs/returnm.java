class returnm
{
	static int multiply() 
	{
		int a=200; 
		int b= 2;
		int c=1;
		int res= a*b*c;
		return res;
	}
	public static void main(String[] args) 
	{
		int x= multiply();
        System.out.println(x);
	}
}
