class zomato 
{
 void order()
{
 System.out.println("They have ordered successfully");
}
}
class roop
{
	 static void buy(zomato  a)
{
		 a.order();
}
}
class sonu
{
	static void buy(zomato  b) 
{
		 b.order();
}
}
class tracker
{
 public static void main(String[] args) 
{
		zomato  p = new zomato ();
		roop.buy(p);
		sonu.buy(p);
}
}
